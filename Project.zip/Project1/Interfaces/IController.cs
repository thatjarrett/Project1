﻿using Microsoft.Xna.Framework;

namespace Project1.Interfaces
{
    internal interface IController
    {
        void Update(GameTime gameTime);
    }
}
