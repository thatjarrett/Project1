﻿namespace Project1.Interfaces
{
    public interface ICommand
    {
        void Execute();
    }
}
