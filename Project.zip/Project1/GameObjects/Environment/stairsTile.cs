﻿using Microsoft.Xna.Framework;

namespace Project1.GameObjects.Environment
{
    public class stairsTile : environmentTile
    {
        public stairsTile(Vector2 pos) :
            base(pos, false, 4)
        {

        }
    }
}
