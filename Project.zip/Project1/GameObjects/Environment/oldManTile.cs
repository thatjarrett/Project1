﻿using Microsoft.Xna.Framework;

namespace Project1.GameObjects.Environment
{
    public class oldManTile : environmentTile
    {
        public oldManTile(Vector2 pos) :
            base(pos, true, 6)
        {

        }
    }
}
