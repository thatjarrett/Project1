﻿using Microsoft.Xna.Framework;

namespace Project1.GameObjects.Environment
{
    public class pushableBlock : blockTile
    {
        public pushableBlock(Vector2 pos) :
            base(pos)
        {

        }


        private void push()
        {

        }
    }
}
