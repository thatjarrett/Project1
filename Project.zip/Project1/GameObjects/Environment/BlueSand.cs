﻿using Microsoft.Xna.Framework;

namespace Project1.GameObjects.Environment
{
    public class BlueSand : environmentTile
    {
        public BlueSand(Vector2 pos, int id) :
            base(pos, true, id)
        { }
    }
}
