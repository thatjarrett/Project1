﻿using Microsoft.Xna.Framework;

namespace Project1.GameObjects.Environment
{
    public class blockTile : environmentTile
    {
        public blockTile(Vector2 pos) :
            base(pos, true, 2)
        {

        }
    }
}
