﻿using System;

public class TileLoader
{
	public TileLoader()
	{
	}
}
