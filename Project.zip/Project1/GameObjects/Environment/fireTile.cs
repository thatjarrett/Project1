﻿using Microsoft.Xna.Framework;

namespace Project1.GameObjects.Environment
{
    public class fireTile : environmentTile
    {
        public fireTile(Vector2 pos) :
            base(pos, true, 5)
        {

        }
    }
}
