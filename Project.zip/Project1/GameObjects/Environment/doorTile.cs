﻿using Microsoft.Xna.Framework;

namespace Project1.GameObjects.Environment
{
    public class doorTile : environmentTile
    {
        public doorTile(Vector2 pos, int id) :
            base(pos, true, id)
        {

        }
    }
}
