﻿namespace Project1.Entities
{
    public enum Direction
    {
        Up,
        Down,
        Left,
        Right,
        None
    }
}
