﻿using var game = new Game1();
game.Run();
